#!/bin/bash

SCRIPT_NAME=$(basename "$0")
if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG_FILE="report_${SCRIPT_NAME%.sh}.log"
PID=$$
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
echo "$START_TIME [$PID] Скрипт запущен" >> "$LOG_FILE"

PIPE="/tmp/run/cuckoo.pid"
if [ ! -p "$PIPE" ]; then
    echo "Ошибка: канал $PIPE не существует" >> "$LOG_FILE"
    exit 1
fi

REQUEST="${SCRIPT_NAME%.sh}[$PID]: how much time do I have?"
echo "$REQUEST" > "$PIPE"
read -r N < "$PIPE"
sleep "$N"

END_TIME=$(date '+%Y-%m-%d %H:%M:%S')
echo "$END_TIME [$PID] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
