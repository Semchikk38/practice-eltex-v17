#!/bin/bash

PIPE="/tmp/run/cuckoo.pid"
LOG="/tmp/cuckoo.log"

if [ ! -p "$PIPE" ]; then
    mkfifo "$PIPE"
fi

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
}

log "Startup!"

trap 'log "Shutdown!"; rm -f "$PIPE"; exit 0' SIGTERM

while true; do
    if read -r request < "$PIPE"; then
        if [[ "$request" =~ ^(.*)\[(.*)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            N=$(( RANDOM % 9 + 2 ))
            echo "$N" > "$PIPE"
            log "$NAME[$PID] $N"
        else
            echo "0" > "$PIPE"
        fi
    fi
done
