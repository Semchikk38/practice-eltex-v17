#!/bin/bash

CONFIG="/root/observer.conf"
LOG="/root/observer.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
}

if [ ! -f "$CONFIG" ]; then
    log "Файл конфигурации $CONFIG не найден"
    exit 1
fi

while IFS= read -r script_path; do
    [[ -z "$script_path" || "$script_path" =~ ^# ]] && continue
    if [ ! -f "$script_path" ]; then
        log "Скрипт $script_path не найден"
        continue
    fi
    proc_name=$(basename "$script_path")
    if pgrep -x "$proc_name" > /dev/null; then
        log "$proc_name уже запущен"
    else
        nohup "$script_path" > /dev/null 2>&1 &
        log "$proc_name перезапущен"
    fi
done < "$CONFIG"
